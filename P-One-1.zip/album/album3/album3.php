<div class="container gallery-album">
<?php
  include designtopia .'album.php';
?>

   <div class="row">
      <a href="?alb=album3&dtl=caption1">
         <div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('album/album3/media/1.jpeg')"></div>
      </a>
      <a href="?alb=album3&dtl=caption2">
         <div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('album/album3/media/2.jpeg')"></div>
      </a>
      <a href="?alb=album3&dtl=caption3">
         <div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('album/album3/media/3.jpeg')"></div>
      </a>
   </div>
   <div class="row">
      <a href="?alb=album3&dtl=caption4">
         <div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('album/album3/media/4.jpeg')"></div>
      </a>
      <a href="?alb=album3&dtl=caption5">
         <div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('album/album3/media/5.jpeg')"></div>
      </a>
      <a href="?alb=album3&dtl=caption6">
         <div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('album/album3/media/6.jpeg')"></div>
      </a>
   </div>
   <div class="row">
      <a href="?alb=album3&dtl=caption7">
         <div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('album/album3/media/7.jpeg')"></div>
      </a>
      <a href="?alb=album3&dtl=caption8">
         <div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('album/album3/media/8.jpeg')"></div>
      </a>
      <a href="?alb=album3&dtl=caption9">
         <div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('album/album3/media/9.jpeg')"></div>
      </a>
   </div>
   <div class="row">
      <a href="?alb=album3&dtl=caption10">
         <div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('album/album3/media/10.jpeg')"></div>
      </a>
      <a href="?alb=album3&dtl=caption11">
         <div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('album/album3/media/11.jpeg')"></div>
      </a>
</div>
