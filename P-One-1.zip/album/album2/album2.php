<div class="container gallery-album">
<?php
  include designtopia .'album.php';
?>

   <div class="row">
      <a href="?alb=album2&dtl=caption1">
         <div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('album/album2/media/1.jpeg')"></div>
      </a>
      <a href="?alb=album2&dtl=caption2">
         <div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('album/album2/media/2.jpeg')"></div>
      </a>
      <a href="?alb=album2&dtl=caption3">
         <div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('album/album2/media/3.jpeg')"></div>
      </a>
   </div>

   <div class="row">
      <a href="?alb=album2&dtl=caption4">
         <div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('album/album2/media/4.jpeg')"></div>
      </a>
      <a href="?alb=album2&dtl=caption5">
         <div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('album/album2/media/5.jpeg')"></div>
      </a>
      <a href="?alb=album2&dtl=caption6">
         <div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('album/album2/media/6.jpeg')"></div>
      </a>
   </div>

   <div class="row">
      <a href="?alb=album2&dtl=caption7">
         <div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('album/album2/media/7.jpeg')"></div>
      </a>
      <a href="?alb=album2&dtl=caption8">
         <div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('album/album2/media/8.jpeg')"></div>
      </a>
      <a href="?alb=album2&dtl=caption9">
         <div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('album/album2/media/9.jpeg')"></div>
      </a>
   </div>
</div>
