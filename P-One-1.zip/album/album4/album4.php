<div class="container gallery-album">
<?php
  include designtopia .'album.php';
?>

   <div class="row">
      <a href="#">
         <div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('album/album4/media/dt7.jpg')"></div>
      </a>
      <a href="#">
         <div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('https://astridwonderland.files.wordpress.com/2016/06/poster-a3.jpg?w=620')"></div>
      </a>
      <a href="#">
         <div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('album/album4/media/dt2.jpg')"></div>
      </a>
   </div>
</div>
