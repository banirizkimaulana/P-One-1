<div class="container gallery-album">
<?php
  include designtopia .'album.php';
?>

   <div class="row">
      <a href="#">
         <div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('https://astridwonderland.files.wordpress.com/2016/10/02.jpg?w=620')"></div>
      </a>
      <a href="#">
         <div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('https://astridwonderland.files.wordpress.com/2016/10/03.jpg?w=620')"></div>
      </a>
      <a href="#">
         <div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('https://astridwonderland.files.wordpress.com/2016/10/05.jpg?w=620')"></div>
      </a>
   </div>
</div>
