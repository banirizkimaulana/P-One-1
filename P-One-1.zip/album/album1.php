
<div class="container gallery-album">

   <div class="row">
      <ol class="breadcrumb">
         <li><a href="./">Home</a></li>
         <li class="active">Album 1</li>
      </ol>

      <div class="header center-block">
         <h1><b>Album 1</b></h1>
         <p>[Teks deskripsi singkat] Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
      </div>
   </div>

   <div class="row">
   	<div class="col-xs-4 col-sm-4 col-md-4 thumb">
   		<a href="?dtl=caption1">
   			<img src="media/1.jpg" alt="Thumbnail" class="portrait">
   		</a>
   	</div>

   	<div class="col-xs-4 col-sm-4 col-md-4 thumb">
   		<a href="?dtl=caption2">
   			<img src="media/2.jpeg" alt="Thumbnail" class="portrait">
   		</a>
   	</div>
   	<div class="col-xs-4 col-sm-4 col-md-4 thumb">
   		<a href="?dtl=caption3">
   			<img src="media/3.jpeg" alt="Thumbnail" class="portrait">
   		</a>
   	</div>
   </div>

   <div class="row">
   	<div class="col-xs-4 col-sm-4 col-md-4 thumb">
   		<a href="?dtl=caption4">
   			<img src="media/4.jpeg" alt="Thumbnail" class="portrait">
   		</a>
   	</div>
   	<div class="col-xs-4 col-sm-4 col-md-4 thumb">
   		<a href="?dtl=caption5">
   			<img src="media/5.jpeg" alt="Thumbnail">
   		</a>
   	</div>
   	<div class="col-xs-4 col-sm-4 col-md-4 thumb">
   		<a href="?dtl=caption6">
   			<img src="media/6.jpeg" alt="Thumbnail">
   		</a>
   	</div>
   </div>

   <div class="row">
   	<div class="col-xs-4 col-sm-4 col-md-4 thumb">
   		<a href="?dtl=caption7">
   			<img src="media/7.jpeg" alt="Thumbnail">
   		</a>
   	</div>
   	<div class="col-xs-4 col-sm-4 col-md-4 thumb">
   		<a href="?dtl=caption8">
   			<img src="media/8.jpeg" alt="Thumbnail">
   		</a>
   	</div>
   	<div class="col-xs-4 col-sm-4 col-md-4 thumb">
   		<a href="?dtl=caption9">
   			<img src="media/9.jpeg" alt="Thumbnail">
   		</a>
   	</div>
   </div>

   <div class="row">
   	<div class="col-xs-4 col-sm-4 col-md-4 thumb">
   		<a href="?dtl=caption10">
   			<img src="media/10.jpeg" alt="Thumbnail">
   		</a>
   	</div>
   	<div class="col-xs-4 col-sm-4 col-md-4 thumb">
   		<a href="?dtl=caption11">
   			<img src="media/11.jpeg" alt="Thumbnail">
   		</a>
   	</div>
   	<div class="col-xs-4 col-sm-4 col-md-4 thumb">
   		<a href="?dtl=caption12">
   			<img src="media/12.jpeg" alt="Thumbnail" class="portrait">
   		</a>
   	</div>
   </div>
</div>
