<footer>
   <div class="clearfix col-md-12 col-sm-12">
      <hr>
   </div>

   <div class="container">
       <div class="row">
         <div class="col-md-12 text-center">
            <ul class="social-icon">
                <li><a href="https://www.facebook.com/danardatu" class="fa fa-facebook"></a></li>
                <li><a href="https://twitter.com/danardatu" class="fa fa-twitter"></a></li>
                <li><a href="https://www.linkedin.com/in/danardatu" class="fa fa-linkedin"></a></li>
            </ul>
         </div>
       </div>

       <div class="row">
        <div class="col-md-12 text-center">
           <div class="footer-copyright">
             <p>© 2017 <a href="http://designtopia.id/">DESiGNTOPiA</a> | All Rights Reserved.</p>
           </div>
        </div>
       </div>
   </div>
</footer>

<script src="//code.jquery.com/jquery-3.2.1.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.0.47/jquery.fancybox.min.js"></script>
</body>
</html>
