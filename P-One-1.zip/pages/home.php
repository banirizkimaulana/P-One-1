<div class="container gallery-depan">
	<div class="row">
		<div class="header center-block">
			<p>Welcome to Danardatu Family Travel Memories</p>
		</div>
	</div>

	<div class="row">
		<a href="?alb=album1">
			<div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('album/album1/media/2.jpeg')">
				<figcaption>Alhambra - Grenada</figcaption>
			</div>
		</a>

		<a href="?alb=album2">
			<div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('album/album2/media/2.jpeg')">
				<figcaption>Cordoba</figcaption>
			</div>
		</a>

		<a href="?alb=album3">
			<div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('album/album3/media/4.jpeg')">
				<figcaption>Seville</figcaption>
			</div>
		</a>
	</div>

	<div class="row">
		<a href="#">
			<div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('media/comingsoon.png')">
				<figcaption>Coming Soon</figcaption>
			</div>
		</a>

		<a href="#">
			<div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('media/comingsoon.png')">
				<figcaption>Coming Soon</figcaption>
			</div>
		</a>

		<a href="#">
			<div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('media/comingsoon.png')">
				<figcaption>Coming Soon</figcaption>
			</div>
		</a>
	</div>


	<div class="row">
		<a href="#">
			<div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('media/comingsoon.png')">
				<figcaption>Coming Soon</figcaption>
			</div>
		</a>

		<a href="#">
			<div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('media/comingsoon.png')">
				<figcaption>Coming Soon</figcaption>
			</div>
		</a>

		<a href="#">
			<div class="col-xs-4 col-sm-4 col-md-4 thumb" style="background-image:url('media/comingsoon.png')">
				<figcaption>Coming Soon</figcaption>
			</div>
		</a>
	</div>
</div>
